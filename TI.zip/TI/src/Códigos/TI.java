/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 package Códigos; 
  
import java.sql.Connection; 
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet; 
import java.sql.SQLException;
  
public class TI { 
  
    public static void main(String[] args) { 
        String url = "jdbc:mysql://localhost:3306/idosos"; 
        String user = "root"; // Usuário padrão do MySQL 
        String password = ""; // Senha do MySQL (vazia por padrão no XAMPP) 
  
        try { 
            // Carregar o driver JDBC do MySQL 
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            System.out.println("Conectado ao banco de dados!");
  
            try ( // Estabelecer conexão
                    Connection conn = DriverManager.getConnection(url, user, password)) {
                System.out.println("Conectado ao banco de dados!");
                // Exemplo: Inserir um dado na tabela
                //String sqlInsert = "INSERT INTO servicos (nome,descricao, preco,tipo) VALUES ('Joao', 'hasd', '11', 'dsad')";
                
                //PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsert);
                System.out.println("Conectado ao banco de dados!");
                //pstmtInsert.setString(1, "João");
                System.out.println("Conectado ao banco de dados!");
                //pstmtInsert.executeUpdate();
                System.out.println("Registro inserido com sucesso!");
                // Exemplo: Consultar dados da tabela
                String sqlSelect = "SELECT * FROM servicos";
                PreparedStatement pstmtSelect = conn.prepareStatement(sqlSelect);
                ResultSet rs = pstmtSelect.executeQuery();
                while (rs.next()) {
                    int id = rs.getInt("id_servicos");
                    String nome = rs.getString("nome");
                    String descricao = rs.getString("descricao");
                    String preco = rs.getString("preco");
                    String tipo = rs.getString("tipo");
                    System.out.println("id_serviços: " + id + ", nome: " + nome);
                    System.out.println("id_serviços: " + id + ", descricao: " + descricao);
                    System.out.println("id_serviços: " + id + ", preco: " + preco);
                    System.out.println("id_serviços: " + id + ", tipo: " + tipo);
                    
                }
                // Fechar conexão
            } 
        } catch (Exception  e) { 
            e.printStackTrace(); 
        } 
    }
}
    
    

